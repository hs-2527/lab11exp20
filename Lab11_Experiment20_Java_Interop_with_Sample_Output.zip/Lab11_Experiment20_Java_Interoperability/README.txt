Lab 11 - Experiment 20: Java Interoperability in Clojure

Files included:
- Experiment20_Java_Interoperability.clj: Clojure source code.
- Sample_Output.png: illustrative sample of the expected console output.
- README.txt: run instructions and notes.

The program demonstrates:
1. Java static methods: Math/abs, Math/max, System/currentTimeMillis.
2. Creating Java ArrayList and HashMap objects.
3. Calling instance methods: add, put, size, and get.
4. Converting Java collections to Clojure collections and back.

Run:
1. Open the .clj file in VS Code.
2. Connect Calva using Clojure (projectless).
3. Press Ctrl+Shift+P.
4. Select "Calva: Load/Evaluate Current File".
5. Check the Calva REPL/output.

IMPORTANT:
Sample_Output.png is an illustrative expected-output image, not a screenshot of an actual run on your computer.
Please run the program in Calva and replace it with your own screenshot if your instructor requires proof of execution.
